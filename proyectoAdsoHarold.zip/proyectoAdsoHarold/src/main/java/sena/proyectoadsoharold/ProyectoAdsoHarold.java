/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sena.proyectoadsoharold;

/**
 *
 * @author roble
 */
public class ProyectoAdsoHarold {

    public static void main(String[] args) {
        System.out.println("Hola ADSO virtual 2024!");
    }
}
